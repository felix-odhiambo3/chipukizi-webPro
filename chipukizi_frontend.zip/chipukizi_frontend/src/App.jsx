import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import Home from './pages/Home.jsx';
import Services from './pages/Services.jsx';
import About from './pages/About.jsx';
import Media from './pages/Media.jsx';
import Booknow from './pages/Booknow.jsx';
import Register from './pages/Register.jsx';
import Contact from './pages/Contact.jsx';
import Partner from './pages/Partner.jsx';
import Events from './pages/Events.jsx';
import Login from './pages/Login.jsx';

function App() {
  return (
      <Router>
        <Header />
        <main className="min-h-[70vh]">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/about" element={<About />} />
            <Route path="/media" element={<Media />} />
            <Route path="/register" element={<Register />} />
            <Route path="/booknow" element={<Booknow />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/partners" element={<Partner />} />
            <Route path="/events" element={<Events />} />
            <Route path="/login" element={<Login />} />
            
            {/* Add more routes here */}
          </Routes>
        </main>
        <Footer />
      </Router>
  );
}

export default App;
